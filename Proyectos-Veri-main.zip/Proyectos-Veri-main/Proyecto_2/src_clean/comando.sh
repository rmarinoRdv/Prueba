#source /mnt/vol_NFS_rh003/estudiantes/archivos_config/synopsys_tools.sh;

rm -rfv ls |grep -v ".*\.sv\|.*\.sh";

#vcs -Mupdate test_bench.sv -o salida -ntb_opts uvm-1.2 -full64 -debug_all -kdb -sverilog -l log_test.txt +lint=TFIPC-L;

vcs -Mupdate test_bench.sv -o salida -ntb_opts uvm-1.2 -full64 -sverilog -kdb -lca -debug_acc+all -debug_region+cell+encrypt -l log_test +lint=TFIPC-L -cm line+tgl+cond+fsm+branch+assert -cov +cover=merge;

#./salida -cm line+tgl+cond+fsm+branch+assert +UVM_TIMEOUT=10000 +ntb_random_seed=12345

#verdi -cov -covdir salida.vdb&

# ./salida -cm line+tgl+cond+fsm+branch+assert +ntb_random_seed=12345 96.59