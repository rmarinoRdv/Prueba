num_iterations=5                
base_seed=12345                
output_dir="../Cov"             

for ((i=0; i<num_iterations; i++)); do
    seed=$((base_seed + i*750))                                # 750 porque se ve bonito
    
    echo "Current seed for iteration $i: $seed"

    command="./salida -cm line+tgl+cond+fsm+branch+assert +UVM_TIMEOUT=100000 +ntb_random_seed=$seed"
    
    echo "Executing command: $command"

    result=$($command 2>&1)
    #result=$($command 2>&1 | tee /dev/tty)                    # Para ver los prints en consola 

    #Por si explota
    if [ $? -ne 0 ]; then
        echo "Error in simulation run $i with seed $seed: $result"
        continue
    fi

    # Path para hacer el cp
    vdb_source="./salida.vdb"
    vdb_dest="$output_dir/salida$i.vdb"
    
    cp -r "$vdb_source" "$vdb_dest"
    
    echo "Iteration $i completed with seed $seed. Copied .vdb to $vdb_dest"
done

echo "All simulations completed. Results are in $output_dir."