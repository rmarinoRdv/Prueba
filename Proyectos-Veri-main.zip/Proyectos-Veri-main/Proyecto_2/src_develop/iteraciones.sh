
####################################################################
# Script para iterar una misma simulación en VCS con diferentes    #
# semillas y generar una cov total de todas las iteraciones.       #
#                                                                  #
# Se copian los reportes con errores de cada iteración para        #
# revisión como post-proceso.                                      #
#                                                                  #
# Elaborado por: Tiler Urena                                       #
#                Randall Marino                                    #
#                                                                  #
# Última actualización: 07/11/24                                   #
#                                                                  # 
#################################################################### 


num_iterations=10                               # Número de iteraciones          
base_seed=123457                                # Semilla base
output_dir="../Cov"                             # Path para guardar cada vbd
vdb_source="./salida.vdb"                       # vbd base 
error_report_base_path="./error_report.csv"     # Path base del csv
error_report_dest_path="../Error_Reports"       # Para dest del csv

for ((i=0; i<num_iterations; i++)); do
    seed=$((base_seed + i*750))                                # 750, puede ser lo que sea
    
    echo "Current seed for iteration $i: $seed"

    # Comando a ejecutar
    command="./salida -cm line+tgl+cond+fsm+branch+assert +UVM_TIMEOUT=100000 +ntb_random_seed=$seed"
    
    echo "Executing command: $command"

    result=$($command 2>&1)
    #result=$($command 2>&1 | tee /dev/tty)                    # Para ver los prints en consola 

    # Por si explota
    if [ $? -ne 0 ]; then
        echo "Error in simulation run $i with seed $seed: $result"
        continue
    fi

    # Path para hacer el cp del vdb
    vdb_dest="$output_dir/salida$i.vdb"
    
    cp -r "$vdb_source" "$vdb_dest"
    
    # cp del csv
    cp "$error_report_base_path" "$error_report_dest_path/error_report$i.csv"

    echo "Iteration $i completed with seed $seed. Copied .vdb to $vdb_dest"
done

# Merge de .vdb 
vdb_files=""
for ((i=0; i<num_iterations; i++)); do
    vdb_files+=" $output_dir/salida$i.vdb"
done

# Comando de merge
urg -dir $vdb_files -dbname merged_cov

echo "All simulations completed. Results are in $output_dir. & $error_report_dest_path"