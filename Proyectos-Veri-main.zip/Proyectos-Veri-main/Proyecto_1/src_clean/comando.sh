source /mnt/vol_NFS_rh003/estudiantes/archivos_config/synopsys_tools.sh;
#rm -rfv ls |grep -v ".*\.sv\|.*\.sh";
#vcs -Mupdate test_bench.sv  -o salida -full64 -debug_all -kdb -sverilog -l log_test.txt +lint=TFIPC-L;
vcs -Mupdate test_bench.sv -o salida -full64 -sverilog -kdb -lca -debug_acc+all -debug_region+cell+encrypt -l log_test +lint=TFIPC-L -cm line+tgl+cond+fsm+branch+assert;

./salida -cm line+tgl+cond+fsm+branch+assert

 verdi -cov -covdir salida.vdb&

